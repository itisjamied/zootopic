//
//  MammalsViewController.swift
//  MammalsViewController
//
//  Created by CTechMBP20E on 8/3/21.
//

import UIKit

class MammalsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func pandaButtonTapped(_ sender: Any) {
    }
    @IBAction func sheepButtonTapped(_ sender: Any) {
    }
    @IBAction func meerkatButtonTapped(_ sender: Any) {
    }
    @IBAction func mooseButtonTapped(_ sender: Any) {
    }
     @IBAction func monkeyButtonTapped(_ sender: Any) {
     }
    @IBAction func llamaButtonTapped(_ sender: Any) {
    }
    @IBAction func lionButttonTapped(_ sender: Any) {
    }
    @IBAction func elephantButtonTapped(_ sender: Any) {
    }
    @IBAction func giraffeButtonTapped(_ sender: Any) {
    }
    
    /*
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
